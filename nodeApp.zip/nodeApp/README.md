# Project Title

Note List App

# Project Short Description

This project is created for note listings with crud operations performed in angular.


## Screenshots

Screenshots available in assets folder under application src folder.


## Documentation

[Documentation](https://angular.io/)


## Installation

Install Node if it is not installed on system

```bash
  cd nodeapp
  npm install
  npm start
  
```
    

## Tech Stack

**Client:** Angular, Bootstrap, Javascript

