import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { debounceTime } from 'rxjs/operators';

interface NodeList {
  id: number,
  name: string,
  description: string
}

@Component({
  selector: 'app-nodes',
  templateUrl: './nodes.component.html',
  styleUrls: ['./nodes.component.scss']
})
export class NodesComponent {
  nodeList: NodeList[] = [];
  nodeForm!: FormGroup;
  orginalNodeList: NodeList[] = [];
  noRecordMsg: string = "No record found";
  isEditStatus: boolean = false;
  selectedNode: any;

  /**
   * Creates an instance of NodesComponent.
   * @param {FormBuilder} fbBuilder
   * @memberof NodesComponent
   */

  constructor(private fbBuilder: FormBuilder) {
    this.nodeForm = this.fbBuilder.group({
      id: [],
      name: ['', Validators.required],
      description: ['']
    })
  }


  /**
   * @author : Anant Jain
   * @description : This function is used to add new record in listing
   * @param : No params
   * @memberof NodesComponent
   */
  _saveNodeForm() {
    if (this.nodeForm.valid) {
      if (this.isEditStatus) {
        this._updateNodeForm();
        return;
      }
      const nodeListing: NodeList = {
        id: this._createUniqueRecord(),
        name: this.nodeForm.value.name,
        description: this.nodeForm.value.description
      };
      this.nodeList.push(nodeListing);
      this.orginalNodeList = this.nodeList;
      this._addFormAction();
    }
  }

  /**
 * @author : Anant Jain
 * @description : This is used to perform common activities of add/update form
 * @param {*} e
 * @memberof NodesComponent
 */
  _addFormAction() {
    const closeButton = document.querySelector('.btn-close') as HTMLElement;
    closeButton.click();
    this.nodeForm.reset();
  }

  /**
* @author : Anant Jain
* @description : This is used to reset status of update form.
* @param {*} e
* @memberof NodesComponent
*/

  _hideUpdateAction() {
    this.isEditStatus = false;
  }


  _updateNodeForm() {
    const updateNodeIndex = this.nodeList.findIndex(todo => todo.id === this.selectedNode.id);
    if (updateNodeIndex !== -1) {
      this.nodeList[updateNodeIndex] = {
        ...this.nodeList[updateNodeIndex],
        name: this.nodeForm.value.name,
        description: this.nodeForm.value.description
      };
      this._addFormAction();
    }
  }

  _createUniqueRecord(): number {
    return Math.floor(Math.random() * 90) + 10; // Generates a random number between 10 and 99
  }

  _getNode(node: any) {
    console.log(node);
    this.nodeForm.patchValue({
      name: node.name,
      description: node.description
    });
    this.selectedNode = node;
    this.isEditStatus = true;
  }


  /**
   * @author : Anant Jain
   * @description : This is used to delete particular node
   * @param {*} e
   * @memberof NodesComponent
   */
  _deleteNode(arg: string) {
    this.nodeList = this.nodeList.filter((todo: any) => todo.name !== arg);
  }

  /**
 * @author : Anant Jain
 * @description : This is used to delete all nodes
 * @param {*} e
 * @memberof NodesComponent
 */

  _deleteAlldNodes() {
    this.nodeList = [];
  }

  /**
* @author : Anant Jain
* @description : This is used to search nodes by Name & description
* @param {*} e
* @memberof NodesComponent
*/
  _searchNode(e: any) {
    if (e.target.value) {
      this.nodeList = this.nodeList.filter(todo =>
        todo.name.toLowerCase().includes(e.target.value.toLowerCase()) || todo.description.toLowerCase().includes(e.target.value.toLowerCase())
      );
    } else {
      this.nodeList = this.orginalNodeList;
    }
  }

}
